import torch
import torch.nn as nn

class DeepAverageNetwork(nn.Module):
    def __init__(self, embedding_matrix, num_classes):
        super(DeepAverageNetwork, self).__init__()
        print("New Version")
        # Load pre-trained word embeddings (frozen)
        self.embedding = nn.Embedding.from_pretrained(embedding_matrix, freeze=True)
        
        # Determine dimensions
        d = embedding_matrix.shape[1]  # Embedding size (50D or 300D)
        dh = d  # Set hidden_dim same as embedding_dim for proper transformations
        do = num_classes  # Number of output classes

        # **Matrix Multiplications following the Screenshot**
        # X [m x d] * W^T [d x dh] -> H [m x dh]
        self.fc1 = nn.Linear(d, dh)  
        
        # Bias vector b [1 x dh] is automatically handled in Linear layer
        self.relu = nn.ReLU()

        # H [m x dh] * U^T [dh x do] -> Ŷ [m x do]
        self.fc2 = nn.Linear(dh, do)  

    def forward(self, x):
        """
        Forward pass:
        1. Convert words to embeddings -> X [m x d]
        2. Pool embeddings by averaging -> Still [m x d]
        3. Apply first transformation to hidden space -> H [m x dh]
        4. Apply ReLU activation
        5. Apply final transformation to output space -> Ŷ [m x do]
        """
        x = self.embedding(x)  # X [m x d]
        x = torch.mean(x, dim=1)  # Pool embeddings by averaging
        x = self.fc1(x)  # X * W^T -> H [m x dh]
        x = self.relu(x)  # Apply ReLU
        x = self.fc2(x)  # H * U^T -> Ŷ [m x do]
        return x  # No softmax, handled in CrossEntropyLoss
