# src/dataset.py
import torch
from torch.utils.data import Dataset, DataLoader
from datasets import load_dataset

def get_data_and_embeddings(glove_path):
    ds = load_dataset("SetFit/sst5")
    train_dataset, val_dataset, test_dataset = ds["train"], ds["validation"], ds["test"]
    embedding_matrix, word_to_idx = load_word_vectors(glove_path)
    return train_dataset, val_dataset, test_dataset, embedding_matrix, word_to_idx


def load_word_vectors(filepath: str):
    """
    Load the word vectors from a file and return a dictionary mapping words to their vectors.
    Returns embedding matrix and word-to-index mapping.
    """
    word_to_idx = {}
    vectors = []

    with open(filepath, "r", encoding='utf-8') as file:
        for i, line in enumerate(file):
            word, *vector = line.split()
            word_to_idx[word] = i
            vectors.append([float(num) for num in vector])

    embedding_dim = len(vectors[0])
    print(f"Loaded {len(vectors)} word vectors of size {embedding_dim}")

    word_to_idx['<unk>'] = len(vectors)
    all_vectors = torch.FloatTensor(vectors)
    unk_vector = torch.mean(all_vectors, dim=0)
    vectors.append(unk_vector.tolist())

    embedding_matrix = torch.FloatTensor(vectors)
    return embedding_matrix, word_to_idx


class TextDataset(Dataset):
    def __init__(self, dataset, word_to_idx, max_length=100):
        self.texts = dataset['text']
        self.labels = dataset['label']
        self.word_to_idx = word_to_idx
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx].split()
        indices = [self.word_to_idx.get(word, self.word_to_idx['<unk>']) for word in text[:self.max_length]]
        if len(indices) < self.max_length:
            indices += [self.word_to_idx['<unk>']] * (self.max_length - len(indices))
        return torch.tensor(indices, dtype=torch.long), torch.tensor(self.labels[idx], dtype=torch.long)


def create_dataloaders(train_dataset, val_dataset, test_dataset, word_to_idx, batch_size=128, max_length=100):
    train_data = TextDataset(train_dataset, word_to_idx, max_length)
    val_data = TextDataset(val_dataset, word_to_idx, max_length)
    test_data = TextDataset(test_dataset, word_to_idx, max_length)

    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False)

    return train_loader, val_loader, test_loader