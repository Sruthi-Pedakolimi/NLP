import pandas as pd
import json

def format_and_save_report(report_str, test_loss, hyperparams, csv_path, log_path):
    """
    Format a classification report string, combine with hyperparameters,
    print and save as CSV and log.

    Args:
        report_str (str): Output from classification_report()
        test_loss (float): Final test loss value
        hyperparams (dict): Hyperparameters used
        csv_path (str): Path to save the combined CSV
        log_path (str): Path to save updated logs
    """
    # Format classification report string into DataFrame
    report = report_str.splitlines()
    columns = ['class'] + report[0].split()
    col_1, col_2, col_3, col_4, col_5 = [], [], [], [], []
    for row in report[1:]:
        if len(row.split()) != 0:
            row = row.split()
            if len(row) < 5:
                col_1.append(row[0])
                col_2.append('')
                col_3.append('')
                col_4.append(row[1])
                col_5.append(row[2])
            elif len(row) > 5:
                col_1.append(row[0] + ' ' + row[1])
                col_2.append(row[2])
                col_3.append(row[3])
                col_4.append(row[4])
                col_5.append(row[5])
            else:
                col_1.append(row[0])
                col_2.append(row[1])
                col_3.append(row[2])
                col_4.append(row[3])
                col_5.append(row[4])

    result_df = pd.DataFrame({
        columns[0]: col_1,
        columns[1]: col_2,
        columns[2]: col_3,
        columns[3]: col_4,
        columns[4]: col_5
    })

    # Add test loss to hyperparams and convert to DataFrame
    hyperparams["Test Loss"] = test_loss
    params_df = pd.DataFrame(list(hyperparams.items()), columns=['Hyperparameter', 'Value'])

    # Print report
    print("\n——————Test——————")
    print(result_df)

    # Save to CSV
    with open(csv_path, "w", newline="") as f:
        params_df.to_csv(f, index=False)
        f.write("\n")
        result_df.to_csv(f, index=False)

    # Update logs
    with open(log_path, "r") as fp:
        logs = json.load(fp)
    logs.append("Test loss: {}".format(test_loss))
    with open(log_path, "w") as fp:
        json.dump(logs, fp)