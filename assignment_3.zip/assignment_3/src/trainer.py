import time
import os
import json
import torch
import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, f1_score
from model import LSTM_net
from report import format_and_save_report


def print_training_info(model, optimizer, lr_scheduler, epochs):
    print(f"Total parameters: {sum(p.numel() for p in model.parameters())}, Trainable: {sum(p.numel() for p in model.parameters() if p.requires_grad)}")
    print(f"dropout: {model.dropout}, hidden_dim: {model.hidden_dim}, num_layers: {model.num_layers}, pretrained: {model.pretrain}")
    print(f"lr: {optimizer.param_groups[0]['lr']}, weight_decay: {optimizer.param_groups[0]['weight_decay']}, lr_decay: {lr_scheduler is not None}, epochs: {epochs}")
    if lr_scheduler:
        print(f"step size: {lr_scheduler.step_size}, gamma: {lr_scheduler.gamma}")


def train_model(model, train_loader, val_loader, criterion, optimizer, lr_scheduler, device, model_dir, model_name, epochs):
    model_info = f"{model.dropout}_{model.hidden_dim}_{model.num_layers}_{model.pretrain}"
    log_path = os.path.join(model_dir, f"train_log_{model_info}.json")
    model.to(device)
    logs = []
    best_loss = float('inf')

    print_training_info(model, optimizer, lr_scheduler, epochs)

    for epoch in range(epochs):
        model.train()
        train_loss = []
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            train_loss.append(loss.item())

        avg_train_loss = np.mean(train_loss)
        print(f"[Epoch {epoch+1}] Train Loss: {avg_train_loss:.4f}")

        model.eval()
        val_loss, y_true, y_pred = [], [], []
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                val_loss.append(loss.item())
                preds = torch.argmax(outputs, dim=1)
                y_true.extend(labels.cpu().numpy())
                y_pred.extend(preds.cpu().numpy())

        avg_val_loss = np.mean(val_loss)
        f1 = f1_score(y_true, y_pred, average='macro')
        print(f"[Epoch {epoch+1}] Val Loss: {avg_val_loss:.4f}, Macro F1: {f1:.4f}")

        if avg_val_loss < best_loss:
            best_loss = avg_val_loss
            torch.save(model.state_dict(), f"{model_dir}/{model_name}_{model_info}.pt")
            print(f"Saved model with val loss: {best_loss:.4f}")

        if lr_scheduler:
            lr_scheduler.step()

        logs.append({"epoch": epoch+1, "train_loss": avg_train_loss, "val_loss": avg_val_loss, "val_f1": f1})
        with open(log_path, "w") as f:
            json.dump(logs, f)

    print("Training complete.")


def test_model(model, test_loader, criterion, device, model_dir, model_name):
    model_info = f"{model.dropout}_{model.hidden_dim}_{model.num_layers}_{model.pretrain}"
    model.load_state_dict(torch.load(f"{model_dir}/{model_name}_{model_info}.pt", map_location=device))
    model.to(device)

    predictions, y_labels, test_loss = [], [], []
    model.eval()
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            test_loss.append(loss.item())
            preds = torch.argmax(outputs, dim=1)
            predictions.extend(preds.cpu().numpy())
            y_labels.extend(labels.cpu().numpy())

    avg_test_loss = np.mean(test_loss)
    report = classification_report(y_labels, predictions, digits=4, zero_division=1)
    print("Test Loss:", avg_test_loss)

    hyperparams = {
        'Model Name': model_name,
        'Hidden Dim': model.hidden_dim,
        'Num Layers': model.num_layers,
        'Dropout': model.dropout,
        'Pretrained': model.pretrain
     
        }
    csv_path = f"{model_dir}/result_{model_info}.csv"
    log_path = os.path.join(model_dir, f"train_log_{model_info}.json")
    format_and_save_report(report, avg_test_loss, hyperparams, csv_path, log_path)
